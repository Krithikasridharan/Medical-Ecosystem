/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class PersonDirectory {
     private ArrayList<Person> personList;

    public PersonDirectory() {
        personList = new ArrayList<>();
    }

   
    public ArrayList<Person> getPersonDirectory() {
        return personList;
    }
    
         
    public Person createPerson(String name){
        Person person = new Person();
        person.setFirstName(name);
        personList.add(person);
        return person;
    }

    
    public void removePerson (Person p){
        personList.remove(p);
        
        
    }
}
