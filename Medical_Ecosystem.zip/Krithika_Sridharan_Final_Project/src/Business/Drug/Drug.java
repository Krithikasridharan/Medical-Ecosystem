/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Drug;

import Business.Patient.AdverseEvents;
import Business.WorkQueue.WorkQueue;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class Drug {
    
    private String drugName;
    private String drugManufacturingCompany;
    private String drugComposition;
    private WorkQueue feedbacksOnDrug;

    
    public  Drug(){
        feedbacksOnDrug=new WorkQueue();
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getDrugManufacturingCompany() {
        return drugManufacturingCompany;
    }

    public void setDrugManufacturingCompany(String drugManufacturingCompany) {
        this.drugManufacturingCompany = drugManufacturingCompany;
    }

    public WorkQueue getFeedbacksOnDrug() {
        return feedbacksOnDrug;
    }

    public void setFeedbacksOnDrug(WorkQueue feedbacksOnDrug) {
        this.feedbacksOnDrug = feedbacksOnDrug;
    }

    public String getDrugComposition() {
        return drugComposition;
    }

    public void setDrugComposition(String drugComposition) {
        this.drugComposition = drugComposition;
    }

  
    @Override
    public String toString() {
        return drugName; 
    }
    
        
    
}
