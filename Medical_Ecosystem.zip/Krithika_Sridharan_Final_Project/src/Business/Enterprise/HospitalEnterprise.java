/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Doctor.DoctorDirectory;
import Business.Nurse.NurseDirectory;
import Business.Patient.PatientDirectory;
import Business.Roles.HospitalAdminRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class HospitalEnterprise extends Enterprise {

    private PatientDirectory patientDirectory;
    private DoctorDirectory doctorDirectory;
    private NurseDirectory nurseDirectory;


    public HospitalEnterprise(String name) {
        super(name, EnterpriseType.HospitalEnterprise);
        this.patientDirectory = new PatientDirectory();
        this.doctorDirectory = new DoctorDirectory();
        this.nurseDirectory=new NurseDirectory();
        
    }

    public NurseDirectory getNurseDirectory() {
        return nurseDirectory;
    }

    public void setNurseDirectory(NurseDirectory nurseDirectory) {
        this.nurseDirectory = nurseDirectory;
    }

    public PatientDirectory getPatientDirectory() {
        return patientDirectory;
    }

    public void setPatientDirectory(PatientDirectory patientDirectory) {
        this.patientDirectory = patientDirectory;
    }

    public DoctorDirectory getDoctorDirectory() {
        return doctorDirectory;
    }

    public void setDoctorDirectory(DoctorDirectory doctorDirectory) {
        this.doctorDirectory = doctorDirectory;
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new HospitalAdminRole());
        return role;

    }

}
