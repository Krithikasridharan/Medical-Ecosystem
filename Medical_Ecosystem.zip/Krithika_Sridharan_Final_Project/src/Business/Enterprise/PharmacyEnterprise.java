/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Roles.PharmacistAdminRole;
import Business.Roles.Roles;
import Business.Stock.StockInInventoryDirectory;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class PharmacyEnterprise extends Enterprise {

    private StockInInventoryDirectory stockInInventoryDirectory;

    public PharmacyEnterprise(String name) {
        super(name, EnterpriseType.PharmacyEnterprise);
        stockInInventoryDirectory = new StockInInventoryDirectory();
    }


    public StockInInventoryDirectory getStockInInventoryDirectory() {
        return stockInInventoryDirectory;
    }

    public void setStockInInventoryDirectory(StockInInventoryDirectory stockInInventoryDirectory) {
        this.stockInInventoryDirectory = stockInInventoryDirectory;
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new PharmacistAdminRole());
        return role;

    }
}
