/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Drug.DrugDirectory;
import Business.Roles.DrugManufacturerAdminRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class DrugEnterprise extends Enterprise {

    private DrugDirectory drugDirectory;

    public DrugEnterprise(String name) {
        super(name, EnterpriseType.DrugEnterprise);

        this.drugDirectory = new DrugDirectory();
    }

    public DrugDirectory getDrugDirectory() {
        return drugDirectory;
    }

    public void setDrugDirectory(DrugDirectory drugDirectory) {
        this.drugDirectory = drugDirectory;
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> role = new ArrayList<>();
        role.add(new DrugManufacturerAdminRole());
        return role;

    }

}
