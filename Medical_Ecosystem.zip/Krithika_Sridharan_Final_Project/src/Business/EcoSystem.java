/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Doctor.Doctor;
import Business.Drug.Drug;
import Business.Enterprise.DrugEnterprise;
import Business.Enterprise.Enterprise;
import Business.Enterprise.HospitalEnterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.Patient.Patient;
import Business.Person.Person;
import Business.Person.PersonDirectory;
import Business.Roles.HospitalAdminRole;
import Business.Roles.Roles;
import Business.Roles.SystemAdministratorRole;
import Business.UserAccount.UserAccount;
import Business.WorkQueue.WorkQueue;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author KrithikaSridharan
 */
public class EcoSystem extends Organization {

    private static EcoSystem ecoSystem;
    private ArrayList<Network> networkList;
    private WorkQueue messagesDirectory;
    private WorkQueue attendEmergencyRequests;
    private WorkQueue reportAdverseEvents;
    private WorkQueue drugPrescriptions;
    private WorkQueue drugRequestToDrugManufacturer;
    private PersonDirectory checkForSSN;

    public static EcoSystem getInstance() {
        if (ecoSystem == null) {
            ecoSystem = new EcoSystem();
        }
        Network network = ecoSystem.createNetwork();
        network.setName("a");
        Network network1 = ecoSystem.createNetwork();
        network1.setName("b");

        Enterprise.EnterpriseType type = Enterprise.EnterpriseType.HospitalEnterprise;
        Enterprise.EnterpriseType type1 = Enterprise.EnterpriseType.DrugEnterprise;

        Enterprise enterprise = network.getEnterpriseDirectory().createEnterprise("BB", type);
        Enterprise enterprise2 = network.getEnterpriseDirectory().createEnterprise("BBB", type1);
        Enterprise enterprise1 = network.getEnterpriseDirectory().createEnterprise("CC", type);
        Person person = enterprise.getPersonDirectory().createPerson("hh");
        Person person1 = enterprise1.getPersonDirectory().createPerson("hhh");
        Person person2 = enterprise2.getPersonDirectory().createPerson("hhh");
        UserAccount account = enterprise.getUserAccountDirectory().createUserAccount("hh", "hh", person, new HospitalAdminRole());
        UserAccount account1 = enterprise1.getUserAccountDirectory().createUserAccount("hhh", "hhh", person1, new HospitalAdminRole());
        Organization h = enterprise.getOrganizationDirectory().createOrganization(Type.HospitalManagementOrganization);
        Organization d = enterprise.getOrganizationDirectory().createOrganization(Type.DoctorOrganization);
        Organization p = enterprise.getOrganizationDirectory().createOrganization(Type.PatientAdministratorOrganization);
        Organization h1 = enterprise1.getOrganizationDirectory().createOrganization(Type.HospitalManagementOrganization);
        Organization d1 = enterprise1.getOrganizationDirectory().createOrganization(Type.DoctorOrganization);
        Organization p1 = enterprise1.getOrganizationDirectory().createOrganization(Type.PatientAdministratorOrganization);
        Organization drug1 = enterprise2.getOrganizationDirectory().createOrganization(Type.DrugManufacturerOrganization);
        h.getUserAccountDirectory().createUserAccount("hm", "hm", h.getPersonDirectory().createPerson("hm"), h.getSupportedRole().get(0));
        p.getUserAccountDirectory().createUserAccount("pp", "pp", p.getPersonDirectory().createPerson("pp"), p.getSupportedRole().get(0));
        h1.getUserAccountDirectory().createUserAccount("hm1", "hm1", h1.getPersonDirectory().createPerson("hm1"), h1.getSupportedRole().get(0));
        p1.getUserAccountDirectory().createUserAccount("pp1", "pp1", p1.getPersonDirectory().createPerson("pp1"), p1.getSupportedRole().get(0));
        drug1.getUserAccountDirectory().createUserAccount("drug1", "drug1", drug1.getPersonDirectory().createPerson("drug1"), drug1.getSupportedRole().get(0));
        Doctor de = ((HospitalEnterprise) enterprise).getDoctorDirectory().createDoctor();
        Drug dr = ((DrugEnterprise) enterprise2).getDrugDirectory().addDrug();
        dr.setDrugComposition("comp");
        dr.setDrugName("Crocin");
        dr.setDrugManufacturingCompany(enterprise2.getName());
        de.setFirstName("dd");
        de.setsSN("11");
        de.setContactNumber(1111);
        de.setAddress("as");
        de.setDepartment("as");
        d.getUserAccountDirectory().createUserAccount("dd", "dd", de, d.getSupportedRole().get(0));
        Patient pa = ((HospitalEnterprise) enterprise).getPatientDirectory().createpatient();
        pa.setFirstName("JJ");
        pa.setsSN("111");
        pa.setContactNumber(111);
        pa.setAddress("111");

        Doctor de1 = ((HospitalEnterprise) enterprise1).getDoctorDirectory().createDoctor();

        de1.setFirstName("dd1");
        de1.setsSN("11111");
        de1.setContactNumber(1111);
        de1.setAddress("as");
        de1.setDepartment("as");
        d1.getUserAccountDirectory().createUserAccount("dd1", "dd1", de1, d1.getSupportedRole().get(0));
        Patient pa1 = ((HospitalEnterprise) enterprise1).getPatientDirectory().createpatient();
        pa1.setFirstName("JZ");
        pa1.setsSN("112");
        pa1.setContactNumber(111);
        pa1.setAddress("111");
        return ecoSystem;

    }

    private EcoSystem() {
        super(null);
        networkList = new ArrayList<>();
        messagesDirectory = new WorkQueue();
        attendEmergencyRequests = new WorkQueue();
        reportAdverseEvents = new WorkQueue();
        drugPrescriptions = new WorkQueue();
        drugRequestToDrugManufacturer = new WorkQueue();
        checkForSSN=new PersonDirectory();
                
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    public Network createNetwork() {
        Network network = new Network();
        networkList.add(network);
        return network;
    }

    public boolean checkIfUsernameIsUnique(String username) {

        if (!this.getUserAccountDirectory().checkIfUsernameIsUnique(username)) {
            return false;
        }

        for (Network network : networkList) {
        }

        return true;
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> roleList = new ArrayList<>();
        roleList.add(new SystemAdministratorRole());
        return roleList;
    }

    public PersonDirectory getCheckForSSN() {
        return checkForSSN;
    }

    public void setCheckForSSN(PersonDirectory checkForSSN) {
        this.checkForSSN = checkForSSN;
    }

    public WorkQueue getMessagesDirectory() {
        return messagesDirectory;
    }

    public void setMessagesDirectory(WorkQueue messagesDirectory) {
        this.messagesDirectory = messagesDirectory;
    }

    public WorkQueue getAttendEmergencyRequests() {
        return attendEmergencyRequests;
    }

    public void setAttendEmergencyRequests(WorkQueue attendEmergencyRequests) {
        this.attendEmergencyRequests = attendEmergencyRequests;
    }

    public WorkQueue getReportAdverseEvents() {
        return reportAdverseEvents;
    }

    public void setReportAdverseEvents(WorkQueue reportAdverseEvents) {
        this.reportAdverseEvents = reportAdverseEvents;
    }

    public static EcoSystem getEcoSystem() {
        return ecoSystem;
    }

    public static void setEcoSystem(EcoSystem ecoSystem) {
        EcoSystem.ecoSystem = ecoSystem;
    }

    public WorkQueue getDrugPrescriptions() {
        return drugPrescriptions;
    }

    public void setDrugPrescriptions(WorkQueue drugPrescriptions) {
        this.drugPrescriptions = drugPrescriptions;
    }

    public WorkQueue getDrugRequestToDrugManufacturer() {
        return drugRequestToDrugManufacturer;
    }

    public void setDrugRequestToDrugManufacturer(WorkQueue drugRequestToDrugManufacturer) {
        this.drugRequestToDrugManufacturer = drugRequestToDrugManufacturer;
    }

    
    public boolean duplicateSSN(String sSN)
    {
        boolean a=true;
        for(Person person : checkForSSN.getPersonDirectory() )
        {
            if(person.getsSN().equals(sSN)){
                JOptionPane.showMessageDialog(null, "This SSN already exists in our system");
                a=false;
            }
        }
        return a;
    }
    
}
