/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Patient;

import Business.Allergies.AllergyDirectory;
import Business.Encounter.EncounterHistory;
import Business.Person.Person;

/**
 *
 * @author KrithikaSridharan
 */

public class Patient extends Person {
     
    
    private EncounterHistory encounterHistory;
    private AllergyDirectory allergyDirectory;
    private VitalSignHistory vitalSignHistory;
    
    
    public Patient() {
        encounterHistory = new EncounterHistory();
        allergyDirectory=new AllergyDirectory();
        vitalSignHistory=new VitalSignHistory();
    }

    public AllergyDirectory getAllergyDiectory() {
        return allergyDirectory;
    }

    public void setAllergyDiectory(AllergyDirectory allergyDiectory) {
        this.allergyDirectory = allergyDiectory;
    }

    public VitalSignHistory getVitalSignHistory() {
        return vitalSignHistory;
    }

    public void setVitalSignHistory(VitalSignHistory vitalSignHistory) {
        this.vitalSignHistory = vitalSignHistory;
    }

   
    
    public EncounterHistory getEncounterHistory() {
        return encounterHistory;
    }

    public void setEncounterHistory(EncounterHistory encounterHistory) {
        this.encounterHistory = encounterHistory;
    }

   
    

}
