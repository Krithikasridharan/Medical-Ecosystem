/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Patient;

import Business.Drug.Drug;


/**
 *
 * @author KrithikaSridharan
 */
public class AdverseEvents {
    
    private String invokeAnEvent;
    private Drug drug;

    public String getInvokeAnEvent() {
        return invokeAnEvent;
    }

    public void setInvokeAnEvent(String invokeAnEvent) {
        this.invokeAnEvent = invokeAnEvent;
    }

    public Drug getDrug() {
        return drug;
    }

    public void setDrug(Drug drug) {
        this.drug = drug;
    }

    @Override
    public String toString() {
        return  drug.getDrugName();
    }
    
    
}
