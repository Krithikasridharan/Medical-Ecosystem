/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Drug.Drug;
import Business.Enterprise.DrugEnterprise;
import Business.Enterprise.PharmacyEnterprise;
import Business.Network.Network;

/**
 *
 * @author KrithikaSridharan
 */
public class PharmacyRequestsDrugsToDrugManufacturer extends WorkRequest {

    private Drug drug;
    private int drugQuantity;
    private PharmacyEnterprise PharmacyEnterprise;
    private Network network;
    private DrugEnterprise drugEnterprise;

    public Drug getDrug() {
        return drug;
    }

    public void setDrug(Drug drug) {
        this.drug = drug;
    }

    public int getDrugQuantity() {
        return drugQuantity;
    }

    public void setDrugQuantity(int drugQuantity) {
        this.drugQuantity = drugQuantity;
    }

    public PharmacyEnterprise getPharmacyEnterprise() {
        return PharmacyEnterprise;
    }

    public void setPharmacyEnterprise(PharmacyEnterprise PharmacyEnterprise) {
        this.PharmacyEnterprise = PharmacyEnterprise;
    }

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }


    public DrugEnterprise getDrugEnterprise() {
        return drugEnterprise;
    }

    public void setDrugEnterprise(DrugEnterprise drugEnterprise) {
        this.drugEnterprise = drugEnterprise;
    }
  @Override
    public String toString() {
        return drug.getDrugName();
    }
}
