/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Person.Person;
import Business.Roles.SystemAdministratorRole;
import Business.UserAccount.UserAccount;



/**
 *
 * @author KrithikaSridharan
 */
public class ConfigureSystem {
    
    public static EcoSystem configure(){
        
        EcoSystem system = EcoSystem.getInstance();
        
        Person person = system.getPersonDirectory().createPerson("KrithikaSridharan");
        UserAccount ua =system.getUserAccountDirectory().createUserAccount("sysadmin", "sysadmin", person, new SystemAdministratorRole());
                
        return system;
        }
   
        
        
        
        
    
}
