/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Roles.NurseRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author krithikasridharan
 */
public class NurseOrganization extends Organization{

   
    public NurseOrganization() {
        super(Organization.Type.NurseOrganization.getValue());
    }

    @Override
    public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> r = new ArrayList<>();
        r.add(new NurseRole());
        return r;
    
}}
