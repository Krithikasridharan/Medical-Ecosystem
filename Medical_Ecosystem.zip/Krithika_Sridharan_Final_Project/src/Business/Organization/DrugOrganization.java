/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Organization;

import Business.Roles.DrugManufacturerRole;
import Business.Roles.Roles;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class DrugOrganization extends Organization  {

  public DrugOrganization() {
        super(Organization.Type.DrugManufacturerOrganization.getValue());
    }



    @Override
       public ArrayList<Roles> getSupportedRole() {
        ArrayList<Roles> roles = new ArrayList<>();
        roles.add(new DrugManufacturerRole());
        return roles;
    }
        
         
}
