/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Organization;

import Business.Organization.Organization.Type;
import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class OrganizationDirectory {
    private ArrayList <Organization> organizationDirectory;

    
    public OrganizationDirectory(){
    organizationDirectory = new ArrayList<>();
    }

    public ArrayList<Organization> getOrganizationDirectory() {
        return organizationDirectory;
    }

    public void setOrganizationDirectory(ArrayList<Organization> organizationDirectory) {
        this.organizationDirectory = organizationDirectory;
    }
            
     public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Organization.Type.HospitalManagementOrganization.getValue())){
            organization = new HospitalManagementOrganization();
            organizationDirectory.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.DrugManufacturerOrganization.getValue())){
            organization = new DrugOrganization();
            organizationDirectory.add(organization);
        }
        
          else if (type.getValue().equals(Organization.Type.DoctorOrganization.getValue())){
            organization = new DoctorOrganization();
            organizationDirectory.add(organization);
        }
          
              
        else if (type.getValue().equals(Organization.Type.PharmacyOrganization.getValue())){
            organization = new PharmacyOrganization();
            organizationDirectory.add(organization);
        }
        
        else if (type.getValue().equals(Organization.Type.PatientAdministratorOrganization.getValue())){
            organization = new PatientAdministratorOrganization();
            organizationDirectory.add(organization);
        }
        else if (type.getValue().equals(Organization.Type.NurseOrganization.getValue())){
            organization = new NurseOrganization();
            organizationDirectory.add(organization);
        }
        
        else if (type.getValue().equals(Organization.Type.PatientManagementOrganization.getValue())){
            organization = new PatientManagementOrganization();
            organizationDirectory.add(organization);
        }
        return organization;
        
        
    }
}
