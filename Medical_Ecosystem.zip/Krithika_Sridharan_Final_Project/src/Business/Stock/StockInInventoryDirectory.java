/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Stock;

import java.util.ArrayList;

/**
 *
 * @author KrithikaSridharan
 */
public class StockInInventoryDirectory {

    private ArrayList<StockInInventory> stockDirectory;

    public StockInInventoryDirectory() {
        stockDirectory = new ArrayList<>();
    }

    public ArrayList<StockInInventory> getStockDirectory() {
        return stockDirectory;
    }

    public void setStockDirectory(ArrayList<StockInInventory> stockDirectory) {
        this.stockDirectory = stockDirectory;
    }

    public StockInInventory addStock() {
        StockInInventory stock = new StockInInventory();
        stockDirectory.add(stock);
        return stock;
    }

    public void removeStock(StockInInventory stock) {
        stockDirectory.remove(stock);
    }
}
