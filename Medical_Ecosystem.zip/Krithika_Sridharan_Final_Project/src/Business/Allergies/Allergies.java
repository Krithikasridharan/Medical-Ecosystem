/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Allergies;

import Business.Doctor.Doctor;
import Business.Drug.Drug;
import static Business.Enterprise.Enterprise.EnterpriseType.DrugEnterprise;

/**
 *
 * @author krithikasridharan
 */
public class Allergies {
    
    private Drug drug;
    private String allergyStatus;
    private Doctor doctor;

    public Drug getDrug() {
        return drug;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setDrug(Drug drug) {
        this.drug = drug;
    }

    public String getAllergyStatus() {
        return allergyStatus;
    }

    public void setAllergyStatus(String allergyStatus) {
        this.allergyStatus = allergyStatus;
    }

    @Override
    public String toString() {
        return drug.getDrugName();
    }
    
    
}
