/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Allergies;

import Business.Drug.Drug;
import java.util.ArrayList;

/**
 *
 * @author krithikasridharan
 */
public class AllergyDirectory {
    private ArrayList<Allergies> allergyList;
    
    public AllergyDirectory(){
        allergyList = new ArrayList<>();
        
    }

    public ArrayList<Allergies> getAllergyList() {
        return allergyList;
    }

    public void setAllergyList(ArrayList<Allergies> allergyList) {
        this.allergyList = allergyList;
    }

    
    
   public Allergies addAllergy(){
       Allergies a = new Allergies();
       allergyList.add(a);
       return a;
       
   } 
   
   
   public void deleteAllergy(Allergies a){
       allergyList.remove(a);
   }
}
