/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Doctor;

import Business.Encounter.EncounterHistory;
import Business.Patient.PatientDirectory;
import Business.Person.Person;
import Business.WorkQueue.WorkQueue;

/**
 *
 * @author KrithikaSridharan
 */
public class Doctor extends Person {

    private String department;
    private EncounterHistory enquiries;
    private PatientDirectory patientEnquiries;
    private WorkQueue reportAdverseEventsDirectory;
    
    public Doctor() {
        enquiries = new EncounterHistory();
        patientEnquiries = new PatientDirectory();
        reportAdverseEventsDirectory = new WorkQueue();

    }

    public WorkQueue getReportAdverseEventsDirectory() {
        return reportAdverseEventsDirectory;
    }

    public void setReportAdverseEventsDirectory(WorkQueue reportAdverseEventsDirectory) {
        this.reportAdverseEventsDirectory = reportAdverseEventsDirectory;
    }

    public EncounterHistory getEnquiries() {
        return enquiries;
    }

    public void setEnquiries(EncounterHistory enquiries) {
        this.enquiries = enquiries;
    }

   
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

  
    public PatientDirectory getPatientEnquiries() {
        return patientEnquiries;
    }

    public void setPatientEnquiries(PatientDirectory patientEnquiries) {
        this.patientEnquiries = patientEnquiries;
    }

}
